#!/bin/sh

if test "$(uname)" = "Linux" && test "$(hostname)" = "vm1"; then
    exit 0
fi

exit 1


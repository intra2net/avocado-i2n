#!/bin/sh

if test "$(uname)" = "Linux" && test "$(hostname)" = "$1"; then
    exit 0
fi

exit 1

